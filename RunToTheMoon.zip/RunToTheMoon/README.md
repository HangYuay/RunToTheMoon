# 🏃 RunLog TH — Run To The Moon

บันทึกประวัติการวิ่งในประเทศไทย ปี 2569 (2026)  
Built with **React + Vite** · Font **Prompt** · **Glassmorphism UI** · Anime Background

## Features
- 📊 Dashboard — สถิติ, BMI, สัดส่วนประเภทการวิ่ง
- ✍️ บันทึกการวิ่ง — เลือกจากปฏิทินงานวิ่งจริง 18 รายการ
- 📋 ประวัติการวิ่ง — กรอง Road / Trail
- 📅 ปฏิทินงานวิ่ง — งานวิ่งทั่วไทย ปี 2569
- 👤 โปรไฟล์นักวิ่ง — รูปภาพ, น้ำหนัก, ส่วนสูง, BMI
- ✨ AI Coach — วิเคราะห์การวิ่งด้วย Claude API

## Deploy on Railway
[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app)

## Local Development
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```
